"""OpenSeries.openseries.__init__.py."""
